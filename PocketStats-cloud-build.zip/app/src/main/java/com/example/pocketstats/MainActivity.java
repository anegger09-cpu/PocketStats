package com.example.pocketstats;
import android.app.*; import android.os.*; import android.content.*; import android.net.Uri; import android.provider.Settings; import android.view.*; import android.widget.*;
public class MainActivity extends Activity {
 public void onCreate(Bundle b){super.onCreate(b); LinearLayout r=new LinearLayout(this); r.setOrientation(1); r.setPadding(24,24,24,24);
 TextView t=new TextView(this); t.setText("Pocket Stats"); t.setTextSize(28);
 TextView d=new TextView(this); d.setText("Floating session tracker. Enter gains manually. This app does not interact with Pokémon GO.");
 Button p=new Button(this); p.setText("Grant display-over-apps permission"); p.setOnClickListener(v->{if(!Settings.canDrawOverlays(this))startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:"+getPackageName())));});
 Button s=new Button(this); s.setText("Show floating tracker"); s.setOnClickListener(v->{if(Settings.canDrawOverlays(this))startService(new Intent(this,OverlayService.class));else Toast.makeText(this,"Grant overlay permission first",0).show();});
 r.addView(t);r.addView(d);r.addView(p);r.addView(s);setContentView(r);}
}
