package com.example.pocketstats;
import android.app.*; import android.content.*; import android.graphics.PixelFormat; import android.os.*; import android.view.*; import android.widget.*; import java.util.Locale;
public class OverlayService extends Service {
 WindowManager wm; View panel; EditText dust,xp,catchCount; TextView stats; long start,d=0,x=0,c=0;
 public void onCreate(){super.onCreate();start=System.currentTimeMillis();wm=(WindowManager)getSystemService(WINDOW_SERVICE);panel=makePanel();int type=Build.VERSION.SDK_INT>=26?WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY:WindowManager.LayoutParams.TYPE_PHONE;
 WindowManager.LayoutParams lp=new WindowManager.LayoutParams(-2,-2,type,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT);lp.gravity=Gravity.TOP|Gravity.START;lp.x=25;lp.y=120;wm.addView(panel,lp);}
 View makePanel(){LinearLayout box=new LinearLayout(this);box.setOrientation(1);box.setPadding(14,10,14,10);box.setBackgroundColor(0xEE20242A);
 TextView h=new TextView(this);h.setText("POCKET STATS • drag here");h.setTextColor(-1);h.setTextSize(16);h.setOnTouchListener(new View.OnTouchListener(){float sx,sy;int ox,oy;public boolean onTouch(View v,MotionEvent e){WindowManager.LayoutParams lp=(WindowManager.LayoutParams)panel.getLayoutParams();if(e.getAction()==0){sx=e.getRawX();sy=e.getRawY();ox=lp.x;oy=lp.y;return true;}if(e.getAction()==2){lp.x=ox+(int)(e.getRawX()-sx);lp.y=oy+(int)(e.getRawY()-sy);wm.updateViewLayout(panel,lp);return true;}return true;}});
 stats=new TextView(this);stats.setTextColor(-1);dust=field("Stardust gained");xp=field("XP gained");catchCount=field("Pokémon caught");
 Button add=new Button(this);add.setText("Add gains");add.setOnClickListener(v->{d+=val(dust);x+=val(xp);c+=val(catchCount);dust.setText("");xp.setText("");catchCount.setText("");refresh();});
 Button close=new Button(this);close.setText("Close overlay");close.setOnClickListener(v->stopSelf());box.addView(h);box.addView(stats);box.addView(dust);box.addView(xp);box.addView(catchCount);box.addView(add);box.addView(close);refresh();return box;}
 EditText field(String s){EditText e=new EditText(this);e.setSingleLine(true);e.setHint(s);e.setInputType(2);return e;} long val(EditText e){try{return Math.max(0,Long.parseLong(e.getText().toString()));}catch(Exception z){return 0;}}
 void refresh(){double hr=Math.max((System.currentTimeMillis()-start)/3600000.0,1.0/60.0);stats.setText(String.format(Locale.US,"Session %.1f min\nDust %,d (%,.0f/hr)\nXP %,d (%,.0f/hr)\nCatches %,d (%.1f/hr)",hr*60,d,d/hr,x,x/hr,c,c/hr));}
 public int onStartCommand(Intent i,int f,int id){return START_NOT_STICKY;} public void onDestroy(){if(panel!=null)wm.removeView(panel);super.onDestroy();} public IBinder onBind(Intent i){return null;}
}
