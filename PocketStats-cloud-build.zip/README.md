Pocket Stats cloud build project.

Create a GitHub repository named PocketStats. Upload the contents of this folder, including the hidden .github/workflows/android.yml path. Open Actions, run Build Pocket Stats APK, then download the PocketStats-debug-apk artifact from the completed run and extract app-debug.apk.

This is a separate floating tracker. It does not inject into, inspect, modify, or automate Pokémon GO. Stardust, XP and catches are manually entered. Android overlay permission is required. KernelSU is not needed for this tracker.
